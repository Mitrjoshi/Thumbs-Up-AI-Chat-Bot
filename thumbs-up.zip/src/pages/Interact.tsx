/* eslint-disable @typescript-eslint/ban-ts-comment */
import { useRef, useState, useEffect, useCallback } from "react";
import StreamingAvatar, {
  AvatarQuality,
  StreamingEvents,
  TaskMode,
  TaskType,
  VoiceEmotion,
} from "@heygen/streaming-avatar";
import { Pause, Play } from "lucide-react";
import { toast } from "sonner";

const Interact = () => {
  const avatar = useRef<StreamingAvatar | null>(null);
  const isStoppedRef = useRef<boolean>(false); // Track if capturing has been stopped

  const [stream, setStream] = useState<MediaStream>();
  const mediaStream = useRef<HTMLVideoElement>(null);
  const [sessionStart, setSessionStart] = useState(false);
  const [userInteracted, setUserInteracted] = useState(false); // Track user interaction
  const [isUserTalking, setIsUserTalking] = useState(false);

  const [streamLoaded, setStreamLoaded] = useState(false);

  const startCapturing = useCallback(async () => {
    if (sessionStart) return;

    isStoppedRef.current = false;
    setSessionStart(true);

    await avatar?.current?.startVoiceChat();
  }, [sessionStart]);

  const stopCapturing = () => {
    setSessionStart(false);
  };

  async function fetchAccessToken() {
    try {
      const res = await fetch(
        "https://api.heygen.com/v1/streaming.create_token",
        {
          method: "POST",
          headers: {
            "x-api-key": import.meta.env.VITE_HEYGEN_API_KEY,
          },
        }
      );
      const data = await res.json();
      const token = data.data.token;

      avatar.current = new StreamingAvatar({
        token,
      });

      return token;
    } catch (e: unknown) {
      console.log(e);
      toast("Error fetching access token:");
    }
  }

  const startSession = useCallback(async () => {
    const newToken = await fetchAccessToken();

    if (!avatar.current) return;

    avatar.current = new StreamingAvatar({
      token: newToken,
    });

    avatar.current.on(StreamingEvents.AVATAR_START_TALKING, (e) => {
      console.log(e);
    });

    avatar.current.on(StreamingEvents.AVATAR_STOP_TALKING, (e) => {
      console.log(e);
      closeAvatar();
    });

    avatar.current.on(StreamingEvents.STREAM_DISCONNECTED, () => {});

    avatar.current?.on(StreamingEvents.STREAM_READY, async (event) => {
      setStream(event.detail);
    });

    avatar.current?.on(StreamingEvents.USER_START, () =>
      setIsUserTalking(true)
    );

    avatar.current?.on(StreamingEvents.USER_STOP, () =>
      setIsUserTalking(false)
    );

    try {
      await avatar.current.createStartAvatar({
        quality: AvatarQuality.Low,
        avatarName: "953f3b341459408c815ffebb33acfdbe",
        language: "en",
        knowledgeId: "b88c9ae7d1134efda6b626e923104159",
        knowledgeBase: "Comedy",
        voice: {
          emotion: VoiceEmotion.EXCITED,
        },
      });
    } catch (e: unknown) {
      console.log(e);
      toast("Error starting avatar session");
    }
  }, []);

  const closeAvatar = () => {
    if (avatar.current) {
      avatar.current.closeVoiceChat();
    }
  };

  const handleUserInteraction = () => {
    setUserInteracted(true);
    startSession();
  };

  useEffect(() => {
    if (stream && mediaStream.current && userInteracted) {
      mediaStream.current.srcObject = stream;
      mediaStream.current.onloadedmetadata = () => {
        setStreamLoaded(true);
        mediaStream.current!.play().catch(() => {
          setStreamLoaded(false);
          toast.error("Error playing the stream");
        });
      };
    }
  }, [mediaStream, stream, userInteracted]);

  useEffect(() => {
    isStoppedRef.current = false;

    return () => {
      closeAvatar();
    };
  }, []);

  async function init() {
    try {
      await avatar?.current?.speak({
        taskType: TaskType.REPEAT,
        taskMode: TaskMode.SYNC,
        text: "Hey there!, how are you?",
      });
    } catch (e: unknown) {
      console.log(e);
      toast("Error speaking initial text:");
    }
  }

  useEffect(() => {
    if (streamLoaded) {
      init();
    }
  }, [streamLoaded]);

  return (
    <div className="grid grid-rows-[90px,1fr,90px] h-[100dvh]">
      <div className="flex justify-start px-4 items-center">
        <img src="/thumbs-up.svg" alt="" className="h-[70px]" />
      </div>

      {userInteracted ? (
        <div className="h-full flex overflow-hidden">
          <video
            muted={false}
            ref={mediaStream}
            autoPlay
            playsInline
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
            }}
          />
        </div>
      ) : (
        <div className="flex justify-center items-center">
          <p className="text-white px-4 text-center">
            Click on the button below to start voice chat!
          </p>
        </div>
      )}

      {userInteracted ? (
        <div className="flex justify-center items-center">
          {mediaStream.current?.canPlayType && streamLoaded ? (
            <>
              <button
                className="bg-[#ff2d21] p-4 rounded-full disabled:opacity-50"
                onClick={() => {
                  if (sessionStart) {
                    stopCapturing();
                  } else {
                    startCapturing();
                  }
                }}
              >
                {sessionStart ? (
                  <Pause fill="white" color="white" />
                ) : (
                  <Play fill="white" color="white" />
                )}
              </button>
              {/* {isUserTalking && (
                <img
                  className="h-[64px] invert"
                  src="https://static.heygen.ai/heygen/avatar/streaming-listening-dark.gif"
                  alt=""
                />
              )} */}
            </>
          ) : (
            <div className="flex justify-center items-center absolute top-0 left-0 w-full h-full">
              <p className="text-white">Loading...</p>
            </div>
          )}
        </div>
      ) : (
        <div className="flex justify-center items-center">
          <button
            className="bg-[#ff2d21] h-[40px] text-white w-[50%] rounded-full disabled:opacity-50"
            onClick={handleUserInteraction}
          >
            Start Chatting
          </button>
        </div>
      )}
    </div>
  );
};

export default Interact;
